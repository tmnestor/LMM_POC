# Why Multithreading Works for GPU Inference

Python's Global Interpreter Lock (GIL) normally prevents multiple threads from executing Python bytecode at the same time — even on a multi-core CPU, only one thread runs Python at a time.

But PyTorch is mostly C++/CUDA under the hood. When you call something like `model.generate()`, the actual work happens in:

1. **CUDA kernels** — matrix multiplies, attention, etc. running on the GPU
2. **C++ extension code** — tensor operations in libtorch

PyTorch **explicitly releases the GIL** before entering these native/CUDA code paths (via `pybind11::gil_scoped_release`). That means while GPU 0 is running a forward pass, the GIL is free, so another Python thread can submit work to GPU 1 simultaneously.

The timeline looks like:

```text
Thread 0:  [Python setup] → release GIL → [CUDA kernel on GPU 0] → reacquire GIL → [Python result handling]
Thread 1:  [Python setup] → release GIL → [CUDA kernel on GPU 1] → reacquire GIL → [Python result handling]
                                           ^^^^^^^^^^^^^^^^^^^^^^^^
                                           These run truly in parallel
```

The Python bookkeeping (building inputs, parsing outputs) still serialises under the GIL, but that's microseconds compared to the seconds spent in CUDA inference. So threads give you ~100% GPU utilization across multiple devices without the complexity of multiprocessing.
