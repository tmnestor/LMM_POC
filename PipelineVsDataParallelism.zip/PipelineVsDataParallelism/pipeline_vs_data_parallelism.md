# Pipeline Parallelism vs Data Parallelism for Multi-GPU Inference

## The Choice

We have an 8B vision-language model and multiple GPUs. There are two ways to use them:

- **Pipeline parallelism** — split the *model* across GPUs (each GPU holds different layers)
- **Data parallelism** — split the *data* across GPUs (each GPU holds the complete model)

We chose data parallelism. This document explains why.

---

## How Images Flow Through GPUs

![Image Distribution: Pipeline vs Data Parallelism](image_distribution.png)

**Pipeline parallelism** sends every image through every GPU. The model's 32 transformer layers are distributed — GPU 0 gets layers 0-7, GPU 1 gets layers 8-15, and so on. Each image must traverse the full chain GPU 0 → 1 → 2 → 3, with a hidden state transfer at each boundary.

**Data parallelism** sends each image to exactly one GPU. The 100 images are partitioned — GPU 0 gets images 0-24, GPU 1 gets 25-49, etc. Each GPU holds the complete model and processes its subset independently. No GPU ever talks to another during inference.

---

## Pipeline Parallelism (`device_map="auto"`)

A single `from_pretrained(..., device_map="auto")` call distributes model layers across GPUs based on available memory. HuggingFace describes this as "pretty naive — there is no clever pipeline parallelism involved, just using the GPUs sequentially" [[1]](#references).

![Pipeline Parallelism](hf_pipeline_parallelism.png)

### The Pipeline Bubble

During autoregressive generation, each token requires a full sequential pass through all layers. With layers split across N GPUs, only **one GPU is active at any moment** — the others idle in a "bubble."

- CMU's PipeFill paper measured pipeline bubbles at **15-30% idle time** in training, exceeding 60% in some configurations [[2]](#references)
- For inference on 2 GPUs, each GPU is idle roughly **50% of the time**
- TensorRT-LLM benchmarks show pipeline parallelism across 2 GPUs *reduced* throughput from 22.2 to 21.1 tokens/s and increased latency from 45.1 to 53.9 ms/token [[3]](#references)

The forward pass is inherently sequential — you cannot compute layer 17 until layer 16 produces its output.

### Hidden State Transfer Cost

At every layer boundary between GPUs, the full hidden state must be transferred:

| Quantity | Size |
| --- | --- |
| Per token (4096 hidden dim, bfloat16) | 8 KB |
| Per sequence (2048 tokens) | 16 MB |
| Per batch of 4 sequences | 64 MB |
| Transfer time at PCIe 4.0 (~25 GB/s) | ~0.64 ms per boundary |
| Transfer time at NVLink 3.0 (~600 GB/s) | ~0.03 ms per boundary |

The individual transfers are small, but they happen at **every boundary on every generated token** — hundreds of times per image during autoregressive decoding.

### When Pipeline Parallelism Makes Sense

When the model **does not fit on a single GPU**. A 70B model at 140 GB in bfloat16 cannot fit on an 80 GB A100 — pipeline parallelism across 2 GPUs is the simplest way to run it.

For our 8B model at 16 GB in bfloat16, every GPU we use has enough memory. Pipeline parallelism solves the wrong problem.

---

## Data Parallelism (Chosen)

Load an independent, complete model copy on each GPU. Partition the images. Each GPU processes its chunk independently. Merge results when done.

![Threading Architecture](threading_architecture.png)

### Why It Scales Linearly

Each GPU works independently — zero inter-GPU communication during inference. Adding a GPU adds proportional throughput:

| Configuration | Throughput | How |
| --- | --- | --- |
| 1 GPU, sequential | 1x | Baseline |
| 1 GPU, batched (batch=8) | 3-5x | Vision encoder amortisation |
| 4 GPUs, sequential | ~4x | 4 independent workers |
| **4 GPUs, batched (batch=4 each)** | **~12-20x** | **Data parallelism x batching** |

For bank statements (multi-turn sequential extraction that cannot be batched), data parallelism is the **only** scaling mechanism — 4 GPUs process 4 bank statements concurrently.

### The VRAM Trade-off

Each GPU holds a full model copy. Total VRAM scales linearly:

| GPUs | InternVL3.5-8B (bfloat16) |
| --- | --- |
| 1 | ~18 GB |
| 2 | ~36 GB |
| 4 | ~72 GB |

We trade VRAM efficiency for throughput. On 24 GB GPUs (L4, A10G) or 80 GB GPUs (A100, H100), this is an acceptable trade — each GPU has enough headroom for the model plus KV cache and activations.

### Threading vs Multiprocessing (Implementation Detail)

Both threading and multiprocessing achieve data parallelism. We chose **threading** because PyTorch releases the GIL during CUDA kernel execution, giving us true GPU parallelism without process overhead [[4]](#references):

![Threading vs Multiprocessing](threading_vs_mp_comparison.png)

| Cost | Multiprocessing | Multithreading |
| --- | --- | --- |
| Process/thread creation | ~42 ms (spawn) [[5]](#references) | Microseconds |
| Import `transformers` | Per worker (5+ sec each) [[6]](#references) | Once |
| Result transfer | Pickle via IPC | Direct memory access |
| Startup (4 workers) | 30-60 seconds | Negligible |

This is an implementation choice within data parallelism, not the strategic decision. The strategic decision was data parallelism over pipeline parallelism.

---

## Side-by-Side Comparison

| Criterion | Pipeline Parallelism | Data Parallelism |
| --- | --- | --- |
| **What gets split** | The model (layers across GPUs) | The data (images across GPUs) |
| **Image routing** | Every image visits every GPU | Each image visits 1 GPU |
| **Inter-GPU communication** | Every layer boundary, every token | None |
| **Throughput scaling (4 GPUs)** | ~1x (pipeline bubble) | ~4x (linear) |
| **Combined with per-GPU batching** | Limited by single pipeline | ~12-20x |
| **Works on PCIe (no NVLink)** | Degraded | Full speed |
| **Bank statement multi-turn** | No improvement | Linear speedup |
| **VRAM efficiency** | High (shared weights) | Low (N copies) |
| **Model size requirement** | Any (designed for large models) | Must fit on 1 GPU |
| **Implementation complexity** | Low (device_map="auto") | Low (ThreadPoolExecutor) |

---

## Summary

Pipeline parallelism splits the model so that large models can run across GPUs. It does not improve throughput — it often makes it worse due to pipeline bubbles and transfer overhead.

Data parallelism splits the data so that each GPU works independently on a subset of images. It scales throughput linearly with GPU count, requires no inter-GPU communication, and works on any hardware interconnect.

For an 8B model that fits on a single GPU, the choice is clear: **split the data, not the model.**

---

## References

1. HuggingFace, ["Handling Big Models for Inference"](https://huggingface.co/docs/accelerate/en/concept_guides/big_model_inference) — Accelerate documentation on `device_map="auto"` behaviour
2. Yile Gu et al., ["PipeFill: Using GPUs During Bubbles in Pipeline-Parallel LLM Training"](https://arxiv.org/abs/2410.07192) — CMU, 2024. Pipeline bubble measurements (15-60% idle)
3. NVIDIA TensorRT-LLM, [Issue #1102: Pipeline Parallelism Performance](https://github.com/NVIDIA/TensorRT-LLM/issues/1102) — Benchmarks showing PP2 slower than single GPU
4. PyTorch, ["CUDA Semantics"](https://docs.pytorch.org/docs/stable/notes/cuda.html) — GIL release during CUDA operations, thread-local device selection
5. SuperFastPython, ["Forking is 20x Faster Than Spawning"](https://superfastpython.com/fork-faster-than-spawn/) — Process creation benchmarks (spawn ~42 ms vs fork ~2 ms)
6. HuggingFace Transformers, [Issue #16863: Import Time](https://github.com/huggingface/transformers/issues/16863) — `import transformers` taking 5+ seconds
